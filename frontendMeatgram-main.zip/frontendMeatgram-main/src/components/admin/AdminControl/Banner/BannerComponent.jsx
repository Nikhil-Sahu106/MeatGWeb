import React from "react";
import AddBanner from "./AddBanner";
import RemoveBanner from "./ViewBanner";
function BannerComponent(){

  return(
    <div>
      <AddBanner />
      <RemoveBanner / >
    </div>
  );
}

export default BannerComponent;