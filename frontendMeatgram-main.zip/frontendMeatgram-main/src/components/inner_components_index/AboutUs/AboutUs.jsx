import React from "react";

function AboutUs() {
  return (
    <section className="ABOUT-wrap">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="title">
              <h2>ABOUT US</h2>
            </div>
            <p>
              In publishing and graphic design, Lorem ipsum is a placeholder
              text commonly used to demonstrate the visual form of a document or
              a typeface without relying on meaningful content. Lorem ipsum may
              be used as a placeholder before final copy is available.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AboutUs;
