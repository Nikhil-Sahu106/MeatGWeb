// config.js
const backendUrl = "https://www.backendnew.chersmeatgram.com/"; // Update this to your actual backend URL

export default backendUrl;
